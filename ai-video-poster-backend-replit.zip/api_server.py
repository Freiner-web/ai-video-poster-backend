
from fastapi import FastAPI, Request
from script_gen import generate_script
from voiceover import text_to_speech
from video_assembler import assemble_video

app = FastAPI()

@app.post("/run")
async def run(request: Request):
    data = await request.json()
    topic = data.get("topic", "default topic")
    script = generate_script(topic)
    audio = text_to_speech(script)
    video_path = assemble_video(audio)
    return {"status": "success", "video_path": video_path}
