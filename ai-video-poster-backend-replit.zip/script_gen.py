
def generate_script(topic):
    return f"This is a 30-second engaging script about {topic}."
