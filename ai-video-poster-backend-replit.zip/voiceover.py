
from gtts import gTTS

def text_to_speech(text, filename="voice.mp3"):
    tts = gTTS(text)
    tts.save(filename)
    return filename
